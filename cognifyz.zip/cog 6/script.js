document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('myForm');
    const nameInput = document.getElementById('name');
    const emailInput = document.getElementById('email');
    const messageInput = document.getElementById('message');

    form.addEventListener('submit', function(event) {
        let isValid = true;
        
        
        document.getElementById('nameError').textContent = '';
        document.getElementById('emailError').textContent = '';
        document.getElementById('messageError').textContent = '';

    
        if (nameInput.value.trim() === '') {
            document.getElementById('nameError').textContent = 'Name is required.';
            isValid = false;
        }

        
        const emailPattern = /@/;
        if (!emailPattern.test(emailInput.value)) {
            document.getElementById('emailError').textContent = 'Invalid email address.';
            isValid = false;
        }

        
        if (messageInput.value.trim() === '') {
            document.getElementById('messageError').textContent = 'Message cannot be empty.';
            isValid = false;
        }

        if (!isValid) {
            event.preventDefault(); 
                }
    });
});
