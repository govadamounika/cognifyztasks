document.addEventListener('DOMContentLoaded', function() {

    const apiUrl = 'https://jsonplaceholder.typicode.com/users';
    
    function fetchAndDisplayUsers() {
        fetch(apiUrl)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(users => {
                
                displayUsers(users);
            })
            .catch(error => {
                console.error('There was a problem with the fetch operation:', error);
            });
    }
    
    
    function displayUsers(users) {
        const userContainer = document.getElementById('userContainer');
        userContainer.innerHTML = ''; 
        
        users.forEach(user => {
            const userDiv = document.createElement('div');
            userDiv.className = 'user';
            userDiv.innerHTML = `
                <h2>${user.name}</h2>
                <p><strong>Username:</strong> ${user.username}</p>
                <p><strong>Email:</strong> ${user.email}</p>
                <p><strong>Address:</strong> ${user.address.street}, ${user.address.city}</p>
                <p><strong>Phone:</strong> ${user.phone}</p>
                <p><strong>Website:</strong> <a href="http://${user.website}" target="_blank">${user.website}</a></p>
            `;
            userContainer.appendChild(userDiv);
        });
    }
    
    
    fetchAndDisplayUsers();
});
